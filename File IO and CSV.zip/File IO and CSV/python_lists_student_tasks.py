######################################################################
# Python list tasks                                                  #
######################################################################
# Task 1 create a list using the data below, all elements are string
# data
# data: ford, vauxhall, porshe, fiat, renault

######################################################################
# Task 2 print the emements of the list


######################################################################
# Task 3 print the first element of the list


######################################################################
# Task 4 loop through each element in the list
# and print each element with a counter
# example output>>> 1: value of list element at first position
#                   2: value of list element at second position
#                   ...
#                   X: value of list element at last position


######################################################################
# Task 5 Create an empty list and populate with a random number of
# elements, each element will be a random integer or float




######################################################################
# Task 6 Create a 2 dimensional list
# using the data below
# make of car: ford, vauxhall, porshe, fiat, renault
# value:       15,   12,       23,     10,   2




